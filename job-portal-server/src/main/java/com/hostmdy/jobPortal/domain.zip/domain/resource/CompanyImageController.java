package com.hostmdy.jobPortal.domain.resource;

public class CompanyImageController {

}
