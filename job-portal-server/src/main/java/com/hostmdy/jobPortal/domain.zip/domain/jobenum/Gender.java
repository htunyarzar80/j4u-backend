package com.hostmdy.jobPortal.domain.jobenum;

public enum Gender {
		MALE,FEMALE,CUSTOM

}
