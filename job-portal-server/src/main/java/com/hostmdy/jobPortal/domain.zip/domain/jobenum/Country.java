package com.hostmdy.jobPortal.domain.jobenum;

public enum Country {
	MYANMAR
}
