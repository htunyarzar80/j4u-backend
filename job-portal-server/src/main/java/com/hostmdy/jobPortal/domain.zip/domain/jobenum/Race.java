package com.hostmdy.jobPortal.domain.jobenum;

public enum Race {
       
		KAYIN,BURMESE
}
