package com.hostmdy.jobPortal.domain.jobenum;

public enum JobStatus {
	ACTIVE,CLOSED
}
